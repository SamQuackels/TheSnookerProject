﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Test_Connection
{
    class SQLFunctions
    {
        private bool Frameover;
        private bool leftWon;
        // Haalt lijst van frames gebaseerd op groupmatch ID
        public List<string> getGroupMatchData(int ID, string ConnectString)
        {
            string command = String.Format(@"SELECT ID FROM matches WHERE GroupMatchID = '{0}'", ID);
            List<string> ids = GetData(ConnectString, command);
            command = String.Format(@"SELECT * FROM frames WHERE MatchID = '{0}' OR MatchID = '{1}' OR MatchID = '{2}'", ids[0], ids[1], ids[2]);
            List<string> fids = GetData(ConnectString, command);
            //MessageBox.Show(String.Join(", ",  fids.ToArray()));
            return fids;
        }

        // Voert een SQL commando uit
        public void ExecuteCommand(string connectionString, string commandString)
        {
            // Controleert of er een verbinding is
            if (tryConnection(connectionString))
            {
                // Met gebruik van de connectie
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    // Command aanmaken
                    MySqlCommand command = new MySqlCommand(commandString, connection);
                    // Connectie openen
                    connection.Open();
                    // Commando doorsturen
                    command.ExecuteNonQuery();
                }
            }
        }
        // Test de verbinding met de database
        public bool tryConnection(string connectionString)
        {
            bool connected = true;
            MySqlConnection DBConnect = new MySqlConnection(connectionString);
            try
            {
                DBConnect.Open();
            }
            catch (Exception ex)
            {
                connected = false;
                MessageBox.Show(ex.Message);
            }
            return connected;
        }

        // Haalt data in de vorm van een lijst van de database mbv een sql querie
        public List<string> GetData(string connectionString, string commandString)
        {
            List<string> a = new List<string>();
            // Controleert of er een verbinding is
            if (tryConnection(connectionString))
            {
                // Met gebruik van de connectie
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    // Commando aanmaken
                    MySqlCommand command = new MySqlCommand(commandString, connection);
                    // Connectie openen
                    connection.Open();
                    // Met gebruik van de "DataReader"
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        // Terwijl het verschillende objecten leest 
                        while (reader.Read())
                        {
                            // Laat elk individueel object zien in een MessageBox
                            //MessageBox.Show(String.Format(Convert.ToString(reader[0])));
                            a.Add(String.Format(Convert.ToString(reader[0])));
                        }
                    }
                }
            }
            return a;
        }

        // Voegt een lijst van items aan een listbox toe (handig voor speler selectie)
        public void AddItemsLB(string connectionString, string commandString, ListBox lb)
        {
            if (tryConnection(connectionString))
            {
                lb.Items.Clear();
                // Met gebruik van de connectie
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    // Commando aanmaken
                    MySqlCommand command = new MySqlCommand(commandString, connection);
                    // Connectie openen
                    connection.Open();
                    // Met gebruik van de "DataReader"
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        // Terwijl het verschillende objecten leest 
                        while (reader.Read())
                        {
                            lb.Items.Add(Convert.ToString(reader[0]));
                        }
                    }
                }
            }
        }

        public void AddItemsCB(string connectionString, string commandString, ComboBox cb)
        {
            if (tryConnection(connectionString))
            {
                cb.Items.Clear();
                // Met gebruik van de connectie
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    // Commando aanmaken
                    MySqlCommand command = new MySqlCommand(commandString, connection);
                    // Connectie openen
                    connection.Open();
                    // Met gebruik van de "DataReader"
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        // Terwijl het verschillende objecten leest 
                        while (reader.Read())
                        {
                            cb.Items.Add(Convert.ToString(reader[0]));
                        }
                    }
                }
            }
        }
        // Bepaalt winnaar adhv groupmatch ID, wordt automatisch uitgevoerd
        public void DetermineWinner(string connectString, int ID)
        {
            List<string> IDS = getGroupMatchData(ID, connectString);
            int matcheswon = 0;
            //MessageBox.Show(String.Join(", ", IDS.ToArray()));          
            for (int i = 0; i <= 8; i += 3)
            {
                int matchwon = 0;
                string command = String.Format(@"SELECT user1won FROM frames WHERE ID = '{0}' OR ID = '{1}' OR ID = '{2}'", IDS[0 + i], IDS[1 + i], IDS[2 + i]);
                List<string> a = GetData(connectString, command);
                //MessageBox.Show(String.Join(", ", a.ToArray()));
                a.ForEach(delegate (string s)
                {
                    if (Convert.ToBoolean(s)) matchwon++;
                });
                if (matchwon >= 2)
                {
                    matchwon = 1;
                    matcheswon += 1;
                }
                else matchwon = 0;
                a.Clear();
                //MessageBox.Show(Convert.ToString(matchwon));
                command = String.Format(@"UPDATE matches SET user1won = {0} WHERE Frame1ID = {1}", matchwon, IDS[0 + i]);
                ExecuteCommand(connectString, command);
            }
            if (matcheswon >= 2) matcheswon = 1;
            else matcheswon = 0;
            string c = String.Format(@"UPDATE groupmatches SET group1won = {0} WHERE ID = {1}", matcheswon, ID);
            ExecuteCommand(connectString, c);
        }
        // Maakt nieuwe match aan en zorgt ervoor dat alle data geupload wordt.
        public async Task CreateNewMatchAsync(string connectString, string groupID1, string groupID2, string team1user1ID, string team1user2ID, string team1user3ID, string team2user1ID, string team2user2ID, string team2user3ID)
        {
            string[] users = new string[6] { team1user1ID, team1user2ID, team1user3ID, team2user1ID, team2user2ID, team2user3ID };
            string[] matches = new string[3] { "match1ID", "match2ID", "match3ID" };
            string[] frames = new string[3] { "Frame1ID", "Frame2ID", "Frame3ID" };
            string c = String.Format(@"INSERT INTO groupmatches (group1ID, group2ID) VALUES ('{0}', '{1}');", groupID1, groupID2);
            ExecuteCommand(connectString, c);
            c = String.Format(@"SELECT max(ID)from groupmatches");
            List<string> ls = GetData(connectString, c);
            string gmID = string.Join(",", ls);
            for (int i = 0; i <= 2; i++)
            {
                c = String.Format(@"INSERT INTO matches (GroupMatchID) VALUES ('{0}');", gmID);
                ExecuteCommand(connectString, c);
                c = String.Format(@"SELECT max(ID)from matches");
                ls = GetData(connectString, c);
                string mID = string.Join(",", ls);
                c = String.Format(@"UPDATE groupmatches SET {0} = {1} WHERE ID = {2}", matches[i], mID, gmID);
                ExecuteCommand(connectString, c);
                LoadPage(connectString, Convert.ToInt32(users[i]), Convert.ToInt32(users[i + 3]), Convert.ToInt32(groupID1), Convert.ToInt32(groupID2));
                for (int j = 0; j <= 2; j++)
                {
                    c = String.Format(@"INSERT INTO frames (user1ID, user2ID, matchID) VALUES ('{0}', '{1}', '{2}');", users[i], users[i + 3], mID);
                    ExecuteCommand(connectString, c);
                    c = String.Format(@"SELECT max(ID)from frames");
                    ls = GetData(connectString, c);
                    string fID = string.Join(",", ls);
                    while (!Frameover) { await Task.Delay(1); }
                    bool fwon = leftWon;
                    c = String.Format(@"UPDATE frames SET user1won = {0} WHERE ID = {1}", fwon, fID);
                    ExecuteCommand(connectString, c);
                    c = String.Format(@"UPDATE matches SET {0} = {1} WHERE ID = '{2}'", frames[j], fID, mID);
                    ExecuteCommand(connectString, c);
                    Frameover = false;
                }
            }
            DetermineWinner(connectString, Convert.ToInt32(gmID));
        }
        // Update alles op de form 
        public void LoadPage(string connectString, int lID, int rID, int glID, int grID)
        {
            Form1 OpenForm = (Form1)Application.OpenForms["Form1"];
            OpenForm.UpdatePage("leftScore", "0");
            OpenForm.UpdatePage("rightScore", "0");
            string c = String.Format(@"SELECT name FROM users WHERE ID = {0}", lID);
            List<string> s = GetData(connectString, c);
            OpenForm.UpdatePage("leftName", String.Join("", s.ToArray()));
            c = String.Format(@"SELECT name FROM users WHERE ID = {0}", rID);
            s = GetData(connectString, c);
            OpenForm.UpdatePage("rightName", String.Join("", s.ToArray()));
            c = String.Format(@"SELECT name FROM groups WHERE ID = {0}", glID);
            s = GetData(connectString, c);
            OpenForm.UpdatePage("leftGroup", String.Join("", s.ToArray()));
            c = String.Format(@"SELECT name FROM groups WHERE ID = {0}", grID);
            s = GetData(connectString, c);
            OpenForm.UpdatePage("rightGroup", String.Join("", s.ToArray()));
        }
        // Klein dingetje omdat ik geen andere oplossing kon vinden lol idk mag mss ooit weg
        public void FrameDone(bool win)
        {
            Frameover = true;
            leftWon = win;
        }
        // Maakt ook een nieuwe match aan enkel wordt het niet geupload
        public async Task CreateNewMatchNoUpload(string connectString, string groupID1, string groupID2, string team1user1ID, string team1user2ID, string team1user3ID, string team2user1ID, string team2user2ID, string team2user3ID)
        {
            string[] users = new string[6] { team1user1ID, team1user2ID, team1user3ID, team2user1ID, team2user2ID, team2user3ID };
            string[] matches = new string[3] { "match1ID", "match2ID", "match3ID" };
            string[] frames = new string[3] { "Frame1ID", "Frame2ID", "Frame3ID" };
            string c = String.Format(@"SELECT max(ID)from groupmatches");
            List<string> ls = GetData(connectString, c);
            string gmID = string.Join(",", ls);
            for (int i = 0; i <= 2; i++)
            {
                c = String.Format(@"SELECT max(ID)from matches");
                ls = GetData(connectString, c);
                string mID = string.Join(",", ls);
                LoadPage(connectString, Convert.ToInt32(users[i]), Convert.ToInt32(users[i + 3]), Convert.ToInt32(groupID1), Convert.ToInt32(groupID2));
                for (int j = 0; j <= 2; j++)
                {
                    c = String.Format(@"SELECT max(ID)from frames");
                    ls = GetData(connectString, c);
                    string fID = string.Join(",", ls);
                    while (!Frameover) { await Task.Delay(1); }
                    bool fwon = leftWon;
                    Frameover = false;
                }
            }
        }
        // Verwijdert alle gegevens van een groupmatch adhv ID
        public void DeleteGroupMatch(string connectString, string ID)
        {
            string command = String.Format(@"SELECT ID FROM matches WHERE GroupMatchID = '{0}'", ID);
            List<string> ids = GetData(connectString, command);
            command = String.Format(@"SELECT * FROM frames WHERE MatchID = '{0}' OR MatchID = '{1}' OR MatchID = '{2}'", ids[0], ids[1], ids[2]);
            List<string> fids = GetData(connectString, command);
            fids.ForEach(delegate (string id)
            {
                command = String.Format(@"DELETE FROM frames WHERE ID = {0}", id);
                ExecuteCommand(connectString, command);
            });
            ids.ForEach(delegate (string id)
            {
                command = String.Format(@"DELETE FROM matches WHERE ID = {0}", id);
                ExecuteCommand(connectString, command);
            });
            command = String.Format(@"DELETE FROM groupmatches WHERE ID = '{0}'", ID);
            ExecuteCommand(connectString, command);
        }
    }
}