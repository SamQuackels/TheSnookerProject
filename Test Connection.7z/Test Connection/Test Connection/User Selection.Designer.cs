﻿
namespace Test_Connection
{
    partial class User_Selection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.user1team1 = new System.Windows.Forms.ComboBox();
            this.StartButton = new System.Windows.Forms.Button();
            this.user2team1 = new System.Windows.Forms.ComboBox();
            this.user3team1 = new System.Windows.Forms.ComboBox();
            this.user1team2 = new System.Windows.Forms.ComboBox();
            this.user2team2 = new System.Windows.Forms.ComboBox();
            this.user3team2 = new System.Windows.Forms.ComboBox();
            this.team1 = new System.Windows.Forms.ComboBox();
            this.team2 = new System.Windows.Forms.ComboBox();
            this.startMatch = new System.Windows.Forms.Button();
            this.closeT1U1 = new System.Windows.Forms.Button();
            this.closeT1U2 = new System.Windows.Forms.Button();
            this.closeT1U3 = new System.Windows.Forms.Button();
            this.closeT2U1 = new System.Windows.Forms.Button();
            this.closeT2U2 = new System.Windows.Forms.Button();
            this.closeT2U3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // user1team1
            // 
            this.user1team1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.user1team1.FormattingEnabled = true;
            this.user1team1.Location = new System.Drawing.Point(36, 207);
            this.user1team1.Margin = new System.Windows.Forms.Padding(2);
            this.user1team1.Name = "user1team1";
            this.user1team1.Size = new System.Drawing.Size(135, 21);
            this.user1team1.Sorted = true;
            this.user1team1.TabIndex = 0;
            this.user1team1.Visible = false;
            this.user1team1.SelectedIndexChanged += new System.EventHandler(this.user1team1_SelectedIndexChanged);
            // 
            // StartButton
            // 
            this.StartButton.Location = new System.Drawing.Point(251, 32);
            this.StartButton.Margin = new System.Windows.Forms.Padding(2);
            this.StartButton.Name = "StartButton";
            this.StartButton.Size = new System.Drawing.Size(56, 19);
            this.StartButton.TabIndex = 1;
            this.StartButton.Text = "Start";
            this.StartButton.UseVisualStyleBackColor = true;
            this.StartButton.Click += new System.EventHandler(this.StartButton_Click);
            // 
            // user2team1
            // 
            this.user2team1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.user2team1.FormattingEnabled = true;
            this.user2team1.Location = new System.Drawing.Point(36, 245);
            this.user2team1.Margin = new System.Windows.Forms.Padding(2);
            this.user2team1.Name = "user2team1";
            this.user2team1.Size = new System.Drawing.Size(135, 21);
            this.user2team1.Sorted = true;
            this.user2team1.TabIndex = 2;
            this.user2team1.Visible = false;
            this.user2team1.SelectedIndexChanged += new System.EventHandler(this.user2team1_SelectedIndexChanged);
            // 
            // user3team1
            // 
            this.user3team1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.user3team1.FormattingEnabled = true;
            this.user3team1.Location = new System.Drawing.Point(36, 287);
            this.user3team1.Margin = new System.Windows.Forms.Padding(2);
            this.user3team1.Name = "user3team1";
            this.user3team1.Size = new System.Drawing.Size(135, 21);
            this.user3team1.Sorted = true;
            this.user3team1.TabIndex = 3;
            this.user3team1.Visible = false;
            this.user3team1.SelectedIndexChanged += new System.EventHandler(this.user3team1_SelectedIndexChanged);
            // 
            // user1team2
            // 
            this.user1team2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.user1team2.FormattingEnabled = true;
            this.user1team2.Location = new System.Drawing.Point(435, 207);
            this.user1team2.Margin = new System.Windows.Forms.Padding(2);
            this.user1team2.Name = "user1team2";
            this.user1team2.Size = new System.Drawing.Size(122, 21);
            this.user1team2.Sorted = true;
            this.user1team2.TabIndex = 4;
            this.user1team2.Visible = false;
            this.user1team2.SelectedIndexChanged += new System.EventHandler(this.user1team2_SelectedIndexChanged);
            // 
            // user2team2
            // 
            this.user2team2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.user2team2.FormattingEnabled = true;
            this.user2team2.Location = new System.Drawing.Point(435, 245);
            this.user2team2.Margin = new System.Windows.Forms.Padding(2);
            this.user2team2.Name = "user2team2";
            this.user2team2.Size = new System.Drawing.Size(122, 21);
            this.user2team2.Sorted = true;
            this.user2team2.TabIndex = 5;
            this.user2team2.Visible = false;
            this.user2team2.SelectedIndexChanged += new System.EventHandler(this.user2team2_SelectedIndexChanged);
            // 
            // user3team2
            // 
            this.user3team2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.user3team2.FormattingEnabled = true;
            this.user3team2.Location = new System.Drawing.Point(435, 285);
            this.user3team2.Margin = new System.Windows.Forms.Padding(2);
            this.user3team2.Name = "user3team2";
            this.user3team2.Size = new System.Drawing.Size(122, 21);
            this.user3team2.Sorted = true;
            this.user3team2.TabIndex = 6;
            this.user3team2.Visible = false;
            this.user3team2.SelectedIndexChanged += new System.EventHandler(this.user3team2_SelectedIndexChanged);
            // 
            // team1
            // 
            this.team1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.team1.FormattingEnabled = true;
            this.team1.Location = new System.Drawing.Point(36, 100);
            this.team1.Margin = new System.Windows.Forms.Padding(2);
            this.team1.Name = "team1";
            this.team1.Size = new System.Drawing.Size(195, 21);
            this.team1.Sorted = true;
            this.team1.TabIndex = 7;
            this.team1.SelectedIndexChanged += new System.EventHandler(this.team1_SelectedIndexChanged);
            // 
            // team2
            // 
            this.team2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.team2.FormattingEnabled = true;
            this.team2.Location = new System.Drawing.Point(381, 98);
            this.team2.Margin = new System.Windows.Forms.Padding(2);
            this.team2.Name = "team2";
            this.team2.Size = new System.Drawing.Size(176, 21);
            this.team2.Sorted = true;
            this.team2.TabIndex = 8;
            this.team2.SelectedIndexChanged += new System.EventHandler(this.team2_SelectedIndexChanged);
            // 
            // startMatch
            // 
            this.startMatch.Location = new System.Drawing.Point(251, 245);
            this.startMatch.Margin = new System.Windows.Forms.Padding(2);
            this.startMatch.Name = "startMatch";
            this.startMatch.Size = new System.Drawing.Size(114, 19);
            this.startMatch.TabIndex = 9;
            this.startMatch.Text = "Start Match";
            this.startMatch.UseVisualStyleBackColor = true;
            this.startMatch.Click += new System.EventHandler(this.startMatch_Click);
            // 
            // closeT1U1
            // 
            this.closeT1U1.Location = new System.Drawing.Point(176, 207);
            this.closeT1U1.Margin = new System.Windows.Forms.Padding(2);
            this.closeT1U1.Name = "closeT1U1";
            this.closeT1U1.Size = new System.Drawing.Size(16, 19);
            this.closeT1U1.TabIndex = 10;
            this.closeT1U1.Text = "x";
            this.closeT1U1.UseVisualStyleBackColor = true;
            this.closeT1U1.Visible = false;
            this.closeT1U1.Click += new System.EventHandler(this.closeT1U1_Click);
            // 
            // closeT1U2
            // 
            this.closeT1U2.Location = new System.Drawing.Point(176, 245);
            this.closeT1U2.Margin = new System.Windows.Forms.Padding(2);
            this.closeT1U2.Name = "closeT1U2";
            this.closeT1U2.Size = new System.Drawing.Size(16, 19);
            this.closeT1U2.TabIndex = 11;
            this.closeT1U2.Text = "x";
            this.closeT1U2.UseVisualStyleBackColor = true;
            this.closeT1U2.Visible = false;
            this.closeT1U2.Click += new System.EventHandler(this.closeT1U2_Click);
            // 
            // closeT1U3
            // 
            this.closeT1U3.Location = new System.Drawing.Point(176, 287);
            this.closeT1U3.Margin = new System.Windows.Forms.Padding(2);
            this.closeT1U3.Name = "closeT1U3";
            this.closeT1U3.Size = new System.Drawing.Size(16, 19);
            this.closeT1U3.TabIndex = 12;
            this.closeT1U3.Text = "x";
            this.closeT1U3.UseVisualStyleBackColor = true;
            this.closeT1U3.Visible = false;
            this.closeT1U3.Click += new System.EventHandler(this.closeT1U3_Click);
            // 
            // closeT2U1
            // 
            this.closeT2U1.Location = new System.Drawing.Point(562, 207);
            this.closeT2U1.Margin = new System.Windows.Forms.Padding(2);
            this.closeT2U1.Name = "closeT2U1";
            this.closeT2U1.Size = new System.Drawing.Size(17, 19);
            this.closeT2U1.TabIndex = 13;
            this.closeT2U1.Text = "x";
            this.closeT2U1.UseVisualStyleBackColor = true;
            this.closeT2U1.Visible = false;
            this.closeT2U1.Click += new System.EventHandler(this.closeT2U1_Click);
            // 
            // closeT2U2
            // 
            this.closeT2U2.Location = new System.Drawing.Point(562, 245);
            this.closeT2U2.Margin = new System.Windows.Forms.Padding(2);
            this.closeT2U2.Name = "closeT2U2";
            this.closeT2U2.Size = new System.Drawing.Size(17, 19);
            this.closeT2U2.TabIndex = 14;
            this.closeT2U2.Text = "x";
            this.closeT2U2.UseVisualStyleBackColor = true;
            this.closeT2U2.Visible = false;
            this.closeT2U2.Click += new System.EventHandler(this.closeT2U2_Click);
            // 
            // closeT2U3
            // 
            this.closeT2U3.Location = new System.Drawing.Point(562, 285);
            this.closeT2U3.Margin = new System.Windows.Forms.Padding(2);
            this.closeT2U3.Name = "closeT2U3";
            this.closeT2U3.Size = new System.Drawing.Size(17, 19);
            this.closeT2U3.TabIndex = 15;
            this.closeT2U3.Text = "x";
            this.closeT2U3.UseVisualStyleBackColor = true;
            this.closeT2U3.Visible = false;
            this.closeT2U3.Click += new System.EventHandler(this.closeT2U3_Click);
            // 
            // User_Selection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.closeT2U3);
            this.Controls.Add(this.closeT2U2);
            this.Controls.Add(this.closeT2U1);
            this.Controls.Add(this.closeT1U3);
            this.Controls.Add(this.closeT1U2);
            this.Controls.Add(this.closeT1U1);
            this.Controls.Add(this.startMatch);
            this.Controls.Add(this.team2);
            this.Controls.Add(this.team1);
            this.Controls.Add(this.user3team2);
            this.Controls.Add(this.user2team2);
            this.Controls.Add(this.user1team2);
            this.Controls.Add(this.user3team1);
            this.Controls.Add(this.user2team1);
            this.Controls.Add(this.StartButton);
            this.Controls.Add(this.user1team1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "User_Selection";
            this.Text = "User_Selected";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox user1team1;
        private System.Windows.Forms.Button StartButton;
        private System.Windows.Forms.ComboBox user2team1;
        private System.Windows.Forms.ComboBox user3team1;
        private System.Windows.Forms.ComboBox user1team2;
        private System.Windows.Forms.ComboBox user2team2;
        private System.Windows.Forms.ComboBox user3team2;
        private System.Windows.Forms.ComboBox team1;
        private System.Windows.Forms.ComboBox team2;
        private System.Windows.Forms.Button startMatch;
        private System.Windows.Forms.Button closeT1U1;
        private System.Windows.Forms.Button closeT1U2;
        private System.Windows.Forms.Button closeT1U3;
        private System.Windows.Forms.Button closeT2U1;
        private System.Windows.Forms.Button closeT2U2;
        private System.Windows.Forms.Button closeT2U3;
    }
}